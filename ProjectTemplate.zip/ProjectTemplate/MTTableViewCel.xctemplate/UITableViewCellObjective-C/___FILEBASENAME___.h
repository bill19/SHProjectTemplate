//___FILEHEADER___

___IMPORTHEADER_cocoaTouchSubclass___

@interface ___FILEBASENAMEASIDENTIFIER___ : ___VARIABLE_cocoaTouchSubclass___

/*创建TableviewCell**/
+ (instancetype)cellWithTableView:(UITableView *)tableView;

@end
